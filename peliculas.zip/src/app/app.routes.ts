import { Routes } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { MoviesComponent } from './movies/movies.component';

export const routes: Routes = [
    {path: 'footer',component : FooterComponent},
    {path: 'header',component : HeaderComponent},
    {path: 'movies',component : MoviesComponent}
];
