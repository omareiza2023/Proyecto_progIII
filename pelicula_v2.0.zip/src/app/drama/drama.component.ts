import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Movie } from '../movies/movies';
@Component({
  selector: 'app-drama',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './drama.component.html',
  styleUrl: './drama.component.css'
})
export class DramaComponent {

  drama : Movie []=[
    {
      titulo: "Parasite",
      director: "Bong Joon-ho",
      ano: 2019,
      genero: "Drama",
      duracion: 132,
      url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRS09deJ4C_LJ4btOvd3IZGjkpOBgZU_fByDHtFxVjhiezEQG9572PkaUB4pzmQVM3kOboQNKbML0D8AiJ4x6VRF0xdmDT-8YlLXEjv5A"
  },
  {
    titulo: "La La Land",
    director: "Damien Chazelle",
    ano: 2016,
    genero: "Drama",
    duracion: 128,
    url: "https://pics.filmaffinity.com/la_la_land-472156717-mmed.jpg"
},
{
    titulo: "Forrest Gump",
    director: "Robert Zemeckis",
    ano: 1994,
    genero: "Drama",
    duracion: 142,
    url: "https://pics.filmaffinity.com/forrest_gump-849148775-mmed.jpg"
},
{
    titulo: "El indomable Will Hunting",
    director: "Gus Van Sant",
    ano: 1997,
    genero: "Drama",
    duracion: 126,
    url: "https://pics.filmaffinity.com/good_will_hunting-182421625-mmed.jpg"
}

  ]


}
