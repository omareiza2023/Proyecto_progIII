import { Routes } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { MoviesComponent } from './movies/movies.component';
import { CrimenComponent } from './crimen/crimen.component';
import { DramaComponent } from './drama/drama.component';
import { CienciaFiccionComponent } from './ciencia-ficcion/ciencia-ficcion.component';


export const routes: Routes = [
    {path: 'footer',component : FooterComponent},
    {path: 'header',component : HeaderComponent},
    {path: 'movies',component : MoviesComponent},
    {path:'drama',component : DramaComponent},
    {path:'crimen',component: CrimenComponent},

    {path:'cienciaFiccion', component:CienciaFiccionComponent},
    {path: 'movies/:category', component: MoviesComponent}
];
