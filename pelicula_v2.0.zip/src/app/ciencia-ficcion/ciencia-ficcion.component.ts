import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Movie } from '../movies/movies'; 

@Component({
  selector: 'app-ciencia-ficcion',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './ciencia-ficcion.component.html',
  styleUrl: './ciencia-ficcion.component.css'
})
export class CienciaFiccionComponent implements OnInit{
 
  cienciaficcion : Movie[] =[ 
    {
      titulo: "Matrix",
      director: "Lana Wachowski",
      ano: 1999,
      genero: "Ciencia Ficcion",
      duracion: 136,
      url: "https://pics.filmaffinity.com/the_matrix-155050517-mmed.jpg"
  },
  {
    titulo: "Inception",
    director: "Christopher Nolan",
    ano: 2010,
    genero: "Ciencia Ficción",
    duracion: 148,
    url: "https://pics.filmaffinity.com/inception-499162575-mmed.jpg"
},
{
    titulo: "Pulp Fiction",
    director: "Quentin Tarantino",
    ano: 1994,
    genero: "Crimen",
    duracion: 154,
    url: "https://pics.filmaffinity.com/pulp_fiction-658460419-mmed.jpg"
}



  ]
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }


}
