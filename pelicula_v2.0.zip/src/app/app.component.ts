import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { MoviesComponent } from './movies/movies.component';
import { DebugTracingFeature } from '@angular/router';
import { CrimenComponent } from './crimen/crimen.component';
import { CienciaFiccionComponent } from './ciencia-ficcion/ciencia-ficcion.component';
import { DramaComponent } from './drama/drama.component';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,HeaderComponent, FooterComponent, MoviesComponent,CrimenComponent,DramaComponent,CienciaFiccionComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'peliculas';
}
