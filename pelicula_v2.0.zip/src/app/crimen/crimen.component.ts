import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Movie } from '../movies/movies';


@Component({
  selector: 'app-crimen',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './crimen.component.html',
  styleUrl: './crimen.component.css'
})
export class CrimenComponent implements OnInit{

  crimen : Movie[] =[ 
    {
      titulo: "El Padrino",
      director: "Francis Ford Coppola",
      ano: 1972,
      genero: "Crimen",
      duracion: 175,
      url: "https://es.web.img3.acsta.net/pictures/18/06/12/12/12/0117051.jpg?coixp=49&coiyp=27"
    }


  ]
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }


}

