
export class Movie{
    titulo: string;
    director: string;
    ano:number;
    genero: string;
    duracion: number;
    url: string;
}
