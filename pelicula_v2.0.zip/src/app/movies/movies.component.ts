import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Movie } from './movies';
import { ActivatedRoute } from '@angular/router';
import { CrimenComponent } from '../crimen/crimen.component';
import { DramaComponent } from '../drama/drama.component';
import { CienciaFiccionComponent } from '../ciencia-ficcion/ciencia-ficcion.component';


@Component({
  selector: 'app-movies',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './movies.component.html',
  styleUrl: './movies.component.css'
})
export class MoviesComponent implements OnInit {
  movies: Movie[]=[
    {
        titulo: "El Padrino",
        director: "Francis Ford Coppola",
        ano: 1972,
        genero: "Crimen",
        duracion: 175,
        url: "https://es.web.img3.acsta.net/pictures/18/06/12/12/12/0117051.jpg?coixp=49&coiyp=27"
    },
    {
        titulo: "Matrix",
        director: "Lana Wachowski",
        ano: 1999,
        genero: "Ciencia Ficcion",
        duracion: 136,
        url: "https://pics.filmaffinity.com/the_matrix-155050517-mmed.jpg"
    },
    {
        titulo: "Parasite",
        director: "Bong Joon-ho",
        ano: 2019,
        genero: "Drama",
        duracion: 132,
        url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRS09deJ4C_LJ4btOvd3IZGjkpOBgZU_fByDHtFxVjhiezEQG9572PkaUB4pzmQVM3kOboQNKbML0D8AiJ4x6VRF0xdmDT-8YlLXEjv5A"
    },
    {
      titulo: "Hreditary",
      director: "Ari Aster",
      ano: 2018,
      genero: "Terror",
      duracion: 127,
      url: "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcTfNARM-Z1O9dLs-I4eD2F4Y8r97wbx5oWO567b-Hs6RjhFz6RydP5f85U2RXZcfNatCopGzvdp5EoVSpLL8y3q9DKSQEpRNOX3kpJiIA"
  },
  {
    titulo: "John Wick",
    director: " Chad Stahelski",
    ano: 2014,
    genero: "accion",
    duracion: 127,
    url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT3tLVGxoEWbuio4Jye2ieEEi4ltUkofIIq_w&s"
  },
    
]
   
  ngOnInit(): void {
    
  }

}

